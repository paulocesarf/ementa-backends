-- Questão 1 - INSERTS
INSERT INTO vendas (vendedor, data, valor) VALUES
('Alice', '2025-01-01', 100),
('Alice', '2025-01-05', 200),
('Bob',   '2025-01-01', 150),
('Bob',   '2025-01-10', 100),
('Alice', '2025-01-10', 300),
('Bob',   '2025-01-15', 200);
